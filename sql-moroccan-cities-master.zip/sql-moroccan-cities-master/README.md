## What is this ?
This is a SQL dump of the whole list of Moroccan cities with the région they belong to, in a sister table.

## How to use it ?
Just import the two files ```region.sql``` and ```ville.sql``` (in this order) into your database and get to work !
